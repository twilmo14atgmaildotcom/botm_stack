.. automodule:: scipy.cluster

.. toctree::
   :hidden:

   cluster.vq
   cluster.hierarchy
