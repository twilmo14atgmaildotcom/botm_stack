#ifndef _NPY_ARRAY_GETSET_H_
#define _NPY_ARRAY_GETSET_H_

extern NPY_NO_EXPORT PyGetSetDef array_getsetlist[];

#endif
