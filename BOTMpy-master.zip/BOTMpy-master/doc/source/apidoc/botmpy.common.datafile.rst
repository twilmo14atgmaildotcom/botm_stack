datafile Package
================

:mod:`datafile` Package
-----------------------

.. automodule:: botmpy.common.datafile
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`atf` Module
-----------------

.. automodule:: botmpy.common.datafile.atf
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`datafile` Module
----------------------

.. automodule:: botmpy.common.datafile.datafile
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`gdf` Module
-----------------

.. automodule:: botmpy.common.datafile.gdf
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`nas` Module
-----------------

.. automodule:: botmpy.common.datafile.nas
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wri` Module
-----------------

.. automodule:: botmpy.common.datafile.wri
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`xpd` Module
-----------------

.. automodule:: botmpy.common.datafile.xpd
    :members:
    :undoc-members:
    :show-inheritance:

