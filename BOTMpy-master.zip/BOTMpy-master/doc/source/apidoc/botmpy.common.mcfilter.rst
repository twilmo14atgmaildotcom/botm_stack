mcfilter Package
================

:mod:`mcfilter` Package
-----------------------

.. automodule:: botmpy.common.mcfilter
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mcfilter_py` Module
-------------------------

.. automodule:: botmpy.common.mcfilter.mcfilter_py
    :members:
    :undoc-members:
    :show-inheritance:

