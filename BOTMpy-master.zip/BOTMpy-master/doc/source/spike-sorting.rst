Spike Sorting
=============

Spike sorting is a combined detection and classification task for transient
patterns in time series. In neuroscience this task is found when analysing
voltage traces recorded from the brain of mammals. This kind of recording
yields discrete time series that represent the brain activity of the cortex at
the site under consideration.

Single cells in the cortex (neurons) communicate by means of electrical and
chemical signals. These signals are called action potential (AP), and arise
when a neuron receive enough input signals from other neurons. The AP builds as
an ion current inside the cell body (soma) of the neuron. At certain threshold
levels the current flows out of the soma and is released into a transmission
channel (axon). At terminal points on the axon chemical transmission devices
(sysnapses) communicate the AP to other neurons, in turn exciting ot inhibiting
their activity. The ion current gives rise to a transmembrane potential as
ion are transported from one side of the membrane to the other. This (de-)
polarisation is measurable inside the neuron and in the medium surrounding the
neuron. The time course of the membrane potential during an AP, as measured in
the voltage trace recorded, has a very distinct gestalt, motivating the term
*spike*.

The aim of the spike sorting task is to identify the points in time when an
AP has occurred in the signal (spike detection) and to predict which of the
neurons present has emitted this spike (spike sorting).

.. todo:: might need references

Intracellular Recordings
------------------------

Voltage recordings from the inside of the neuron are called *intracellular
recordings*. This kind of recording can help to understand intracellular
current dynamics. In general the detection of the AP from intracellular
recordings does not pose a challenge, so that this kind of recording will not
be considered in detail here.

.. todo:: might need references

Extracellular recording
-----------------------

The leading paradigm to record ensembles of neurons from the cortex is that
of extracellular recording. An electrode will be placed in the part of the
cortex under consideration and record from the local neuronal population.

.. _`fig-recording`:

.. figure:: static/recording.png
   :alt: cartoon of the experimental setup for extracellular recordings
   :align: center
   :figwidth: 80%
   :height: 300px
   :figclass: align-center

   Cartoon of the experimental setup for extracellular recordings.

Literature Introduction
-----------------------

For further information about spike sorting please refer to the following
publications [Lewiki99]_, [ScholarpediaSS]_ and more recent and recommended
[Einevoll11]_.

Bayes Optimal Template Matching
===============================

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum, neque
eu hendrerit scelerisque, orci nisl auctor risus, pulvinar congue augue turpis
fermentum odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam
venenatis lacinia elit, id aliquet dolor ultricies non. Sed quam massa,
ullamcorper sit amet scelerisque et, volutpat nec erat. Curabitur tincidunt
scelerisque dolor sit amet bibendum. Class aptent taciti sociosqu ad litora
torquent per conubia nostra, per inceptos himenaeos. Cras fermentum hendrerit
mattis. Nam ullamcorper nisl lacinia tortor suscipit sed iaculis augue
dignissim. Integer magna leo, pulvinar a pellentesque in, tincidunt quis lacus.
Donec et urna iaculis elit mollis venenatis. Maecenas a enim vitae arcu semper
ultrices condimentum eu justo. In hac habitasse platea dictumst. Maecenas in
felis quis enim malesuada laoreet.

.. ############################################################################
.. link targets

.. _python: http://python.org
