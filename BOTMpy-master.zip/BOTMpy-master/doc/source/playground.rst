.. _playground:

##########
Playground
##########

This page serves as a plaground to test reST layout elements.

HLIST
-----

.. hlist::
   :columns: 3

   * A list of
   * short items
   * that should be
   * displayed
   * horizontally

Citations
=========

yadda yadda yadda t :cite:t:`einevoll2012spikesorting` yadda yadda

yadda yadda yadda p :cite:p:`einevoll2012spikesorting` yadda yadda

yadda yadda yadda ts :cite:ts:`einevoll2012spikesorting` yadda yadda

yadda yadda yadda ps :cite:ps:`einevoll2012spikesorting` yadda yadda

References
==========

.. cite:refs::
